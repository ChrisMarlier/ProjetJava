import java.awt.Canvas;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Image;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

public class Jeu extends Canvas implements Runnable {

	private static final long serialVersionUID = 1L;

	private Image fondecran;
	private JFrame frame;
	private String title;

	private JLabel gameTitle;
	private Bouton nouvellePartieBtn;
	private Bouton chargerPartieBtn;
	private Bouton aideBtn;

	public Jeu(String title) {
		this.title = title;

		chargerRessources();
		initCanvas();
	}

	private void chargerRessources() {
		// Chargement de l'image de fond d'�cran
		try {
			fondecran = ImageIO.read(Jeu.class.getResource("bg.jpg"));
		} catch (IOException e) {
			e.printStackTrace();
			System.exit(1);
		}
	}

	private void initCanvas() {
		Dimension d = new Dimension(800, 600);
		frame = new JFrame(title);
		frame.setAutoRequestFocus(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setResizable(false);
		frame.setLocationRelativeTo(null);

		frame.setMinimumSize(d);
		frame.setMaximumSize(d);
		frame.setPreferredSize(d);
		frame.setSize(d);
		frame.add(this);

		gameTitle = new JLabel(title);
		gameTitle.setForeground(Color.WHITE);
		gameTitle.setFont(gameTitle.getFont().deriveFont(64.0f));
		gameTitle.setHorizontalAlignment(SwingConstants.CENTER);

		nouvellePartieBtn = new Bouton("Nouvelle Partie");
		chargerPartieBtn = new Bouton("Charger Partie");
		aideBtn = new Bouton("Aide");

		nouvellePartieBtn.addActionListener(new BoutonActionListener(1));
		chargerPartieBtn.addActionListener(new BoutonActionListener(2));
		aideBtn.addActionListener(new BoutonActionListener(3));

		ImagePanel panel = new ImagePanel(fondecran);
		panel.setLayout(new GridLayout(4, 1, 0, 0));
		panel.add(gameTitle);
		panel.add(nouvellePartieBtn);
		panel.add(chargerPartieBtn);
		panel.add(aideBtn);

		frame.add(panel);
		frame.pack();
		frame.setVisible(true);
	}

	@Override
	public void run() {
		while (true) {
			Graphics g = getGraphics();
			if (g != null) {
				g.drawImage(fondecran, 0, 0, this);
			}
			try {
				Thread.sleep(30);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	public static void main(String[] args) {
		Jeu jeu = new Jeu("Titre Jeu");
		jeu.run();
	}

}
